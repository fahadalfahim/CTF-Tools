# Validation record

Date: 2026-10-01. Environment: Windows, Python 3.10.11, Node.js 24.19.0.

## Completed checks

- `python -m unittest discover -s tests -v`: **31 tests passed** (3.172 seconds on the final run).
- `node --check flagforge/static/app.js`: passed.
- `python -m compileall -q flagforge tests`: passed before the final small updates; the final suite imported and exercised the updated Python modules.
- Actual browser use: pasted an encoded question, set prefix `flag`, submitted, observed completed job and `flag{evidence_before_confidence}` with three artifacts and two transformations.
- Actual browser file upload: selected `examples/challenge.txt`, enabled deep inspection, submitted, observed the same expected candidate, evidence hashes and reproduced status.
- Browser console: no captured errors or warnings during those flows.
- Visual inspection: the workbench and completed result were rendered and inspected in the in-app browser. No exhaustive device/accessibility audit was performed.
- Export test: unpacked the generated bundle, executed its standalone solver successfully, then changed original bytes and confirmed that hash verification failed.

## Coverage highlights

Nested ZIP/GZIP/Base64; hex of Base64; direct extraction; UTF-16; XOR; Caesar; ROT13; reversed text; Base32; URL and HTML encoding; binary-byte strings; zlib; PNG low bits (all five filter types on a single-row grayscale fixture); WAV PCM low bits; malformed ZIP/XZ/zlib; bad PNG CRC; decompression limit; TAR symlink exclusion; ZIP path traversal resistance; literal prefix validation; decoy warnings; prevention of invented shifted candidates; HTTP auth/origin/Host checks; persistent output creation; job cancellation.

## Not verified

- Native Linux execution, POSIX resource/process-group limits and passive tool adapters: this host has no installed WSL distribution or Docker executable.
- Docker image build and Compose deployment; the supplied configuration must be verified on the target Linux machine.
- Full PNG color/filter/interlace combinations, WAV formats or arbitrary real-world malformed files. Supported PNG formats are deliberately limited; interlaced and palette PNG are rejected by the low-bit decoder.
- A real held-out competition benchmark, platform submissions or measured solve accuracy.
- Multi-user or Internet-facing deployment, penetration testing, exhaustive fuzzing or long-duration load tests.

Passing these tests verifies specific behaviors, not absence of bugs or a guarantee of challenge correctness. This release provides a functioning deterministic workbench; it does not implement the entire autonomous AI architecture discussed in planning.
