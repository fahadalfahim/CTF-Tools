import base64
import http.client
import json
from pathlib import Path
import tempfile
import threading
import time
import unittest

from flagforge.server import JobStore, Server


class APITests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.temp = tempfile.TemporaryDirectory()
        cls.store = JobStore(cls.temp.name)
        cls.server = Server(("127.0.0.1", 0), cls.store)
        cls.port = cls.server.server_address[1]
        cls.thread = threading.Thread(target=cls.server.serve_forever, daemon=True)
        cls.thread.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown(); cls.server.server_close(); cls.store.close(); cls.thread.join(); cls.temp.cleanup()

    def request(self, method, path, payload=None, auth=True, extra=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.port, timeout=10)
        headers = {"Content-Type": "application/json"}
        if auth:
            headers["Authorization"] = "Bearer " + self.server.token
        headers.update(extra or {})
        connection.request(method, path, json.dumps(payload) if payload is not None else None, headers)
        response = connection.getresponse(); status = response.status; data = response.read(); connection.close()
        return status, data

    def test_static_and_session(self):
        status, data = self.request("GET", "/", auth=False)
        self.assertEqual(status, 200); self.assertIn(b"Every flag has a trail", data)
        status, data = self.request("GET", "/api/session", auth=False)
        self.assertEqual(json.loads(data)["token"], self.server.token)

    def test_auth_and_cross_origin(self):
        self.assertEqual(self.request("GET", "/api/jobs", auth=False)[0], 401)
        self.assertEqual(self.request("GET", "/api/session", extra={"Origin": "https://evil.example"})[0], 403)
        self.assertEqual(self.request("GET", "/api/session", extra={"Host": "evil.example"})[0], 403)
        self.assertEqual(self.request("GET", "/api/session", extra={"Sec-Fetch-Site": "cross-site"})[0], 403)

    def test_validation_and_path_traversal(self):
        self.assertEqual(self.request("POST", "/api/jobs", {})[0], 400)
        self.assertEqual(self.request("GET", "/../README.md")[0], 404)
        self.assertEqual(self.request("GET", "/api/jobs/" + "a" * 32)[0], 404)

    def test_job_and_export(self):
        status, data = self.request("POST", "/api/jobs", {"prefix": "flag", "files": [{"name": "x.txt", "data": base64.b64encode(b"ZmxhZ3thcGlfdGVzdH0=").decode()}]})
        self.assertEqual(status, 202)
        job_id = json.loads(data)["id"]
        deadline = time.monotonic() + 20
        while time.monotonic() < deadline:
            status, data = self.request("GET", "/api/jobs/" + job_id)
            job = json.loads(data)
            if job["status"] not in ("queued", "running", "cancelling"):
                break
            time.sleep(.1)
        self.assertEqual(job["status"], "completed", job)
        self.assertIn("flag{api_test}", [c["value"] for c in job["result"]["candidates"]])
        status, bundle = self.request("GET", "/api/jobs/" + job_id + "/export")
        self.assertEqual(status, 200); self.assertTrue(bundle.startswith(b"PK"))
        self.assertTrue((Path(self.temp.name) / job_id / "job.json").exists())

    def test_cancellation(self):
        status, data = self.request("POST", "/api/jobs", {"question": "Decode this " * 2000, "deep": True})
        self.assertEqual(status, 202)
        job_id = json.loads(data)["id"]
        self.assertEqual(self.request("POST", f"/api/jobs/{job_id}/cancel", {})[0], 200)
        deadline = time.monotonic() + 10
        while time.monotonic() < deadline:
            job = json.loads(self.request("GET", "/api/jobs/" + job_id)[1])
            if job["status"] not in ("queued", "running", "cancelling"):
                break
            time.sleep(.1)
        self.assertEqual(job["status"], "cancelled")


if __name__ == "__main__":
    unittest.main()
