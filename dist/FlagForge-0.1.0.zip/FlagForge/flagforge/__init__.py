"""FlagForge: evidence-oriented local CTF workbench."""

__version__ = "0.1.0"

